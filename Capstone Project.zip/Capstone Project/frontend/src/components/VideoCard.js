import React from 'react';
import { Link } from 'react-router-dom';
export default function VideoCard({v}){
  return (<div className='card'>
    <Link to={'/video/'+v._id}><img src={v.thumbnail||'https://via.placeholder.com/320x180'} alt='' style={{width:'100%'}}/></Link>
    <h4>{v.title}</h4>
    <p style={{fontSize:12}}>{v.channel?.name || 'Channel'} • {v.views} views</p>
  </div>);
}
