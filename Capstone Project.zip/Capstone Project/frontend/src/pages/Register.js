import React, {useState} from 'react';
import API from '../api';
import { useNavigate } from 'react-router-dom';
export default function Register(){
  const [username,setUsername]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const nav = useNavigate();
  const submit = async (e)=>{ e.preventDefault(); const res = await API.post('/auth/register',{username,email,password}); localStorage.setItem('token', res.data.token); nav('/'); };
  return (<div className='container'><h2>Register</h2><form onSubmit={submit}>
    <input value={username} onChange={e=>setUsername(e.target.value)} placeholder='username' /><br/>
    <input value={email} onChange={e=>setEmail(e.target.value)} placeholder='email' /><br/>
    <input value={password} onChange={e=>setPassword(e.target.value)} placeholder='password' type='password' /><br/>
    <button>Register</button>
  </form></div>);
}
