const mongoose = require('mongoose');
const ChannelSchema = new mongoose.Schema({
  name: String,
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  description: String,
  banner: String,
  subscribers: { type: Number, default: 0 },
  videos: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Video' }]
});
module.exports = mongoose.model('Channel', ChannelSchema);
