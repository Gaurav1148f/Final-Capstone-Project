const express = require('express');
const router = express.Router();
const Channel = require('../models/Channel');
const auth = require('../middleware/auth');

router.post('/', auth, async (req,res)=>{
  const {name,description,banner} = req.body;
  const channel = await Channel.create({name,description,banner, owner:req.user});
  res.json(channel);
});

router.get('/:id', async (req,res)=>{
  const c = await Channel.findById(req.params.id).populate('videos');
  if(!c) return res.status(404).json({message:'Not found'});
  res.json(c);
});

module.exports = router;
