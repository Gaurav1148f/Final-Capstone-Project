import React, {useEffect, useState} from 'react';
import { useParams } from 'react-router-dom';
import API from '../api';
export default function Channel(){
  const {id} = useParams();
  const [channel,setChannel] = useState(null);
  useEffect(()=>{ if(id) load(); },[id]);
  const load = async ()=>{ const r = await API.get('/channels/'+id); setChannel(r.data); };
  if(!channel) return <div className='container'>Loading...</div>;
  return (<div className='container'><h2>{channel.name}</h2><p>{channel.description}</p>
    <h3>Videos</h3><div className='grid'>{(channel.videos||[]).map(v=> (<div key={v._id} className='card'><img src={v.thumbnail||'https://via.placeholder.com/320x180'} style={{width:'100%'}}/><h4>{v.title}</h4></div>))}</div>
  </div>);
}
