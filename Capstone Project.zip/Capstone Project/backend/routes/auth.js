const express = require('express');
const router = express.Router();
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const genToken = (id)=> jwt.sign({id}, process.env.JWT_SECRET, {expiresIn:'1d'});

router.post('/register', async (req,res)=>{
  const {username,email,password} = req.body;
  if(!username||!email||!password) return res.status(400).json({message:'All fields required'});
  const exists = await User.findOne({email});
  if (exists) return res.status(400).json({message:'Email in use'});
  const user = await User.create({username,email,password});
  res.json({token:genToken(user._id)});
});

router.post('/login', async (req,res)=>{
  const {email,password} = req.body;
  if(!email||!password) return res.status(400).json({message:'All fields required'});
  const user = await User.findOne({email});
  if(!user) return res.status(400).json({message:'Invalid credentials'});
  const ok = await bcrypt.compare(password, user.password);
  if(!ok) return res.status(400).json({message:'Invalid credentials'});
  res.json({token:genToken(user._id)});
});

module.exports = router;
