import React from 'react';
import { Link } from 'react-router-dom';
export default function Header(){
  return (<div className='header'>
    <div className='container'>
      <Link to='/'><strong>YouTube Clone</strong></Link>
      <span style={{float:'right'}}>
        <Link to='/login'>Sign in</Link>
      </span>
    </div>
  </div>);
}
