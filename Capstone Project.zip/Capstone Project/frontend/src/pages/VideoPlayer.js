import React, {useEffect, useState} from 'react';
import { useParams } from 'react-router-dom';
import API from '../api';
export default function VideoPlayer(){
  const {id} = useParams();
  const [video,setVideo] = useState(null);
  const [comments,setComments] = useState([]);
  const [text,setText] = useState('');
  useEffect(()=>{ if(id) load(); },[id]);
  const load = async ()=>{ const r = await API.get('/videos/'+id); setVideo(r.data); const c = await API.get('/comments/'+id); setComments(c.data); };
  const addComment = async ()=>{ const token = localStorage.getItem('token'); await API.post('/comments/'+id,{text},{ headers: { Authorization: 'Bearer '+token } }); load(); setText(''); };
  if(!video) return <div className='container'>Loading...</div>;
  return (<div className='container'><h2>{video.title}</h2>
    <div style={{background:'#000',height:360,display:'flex',alignItems:'center',justifyContent:'center',color:'#fff'}}>Video Player Placeholder</div>
    <p>{video.description}</p>
    <h3>Comments</h3>
    <div>{comments.map(c=>(<div key={c._id} style={{borderBottom:'1px solid #eee',padding:8}}><b>{c.user?.username||'User'}</b><p>{c.text}</p></div>))}</div>
    <div style={{marginTop:8}}><input value={text} onChange={e=>setText(e.target.value)} placeholder='Add comment'/> <button onClick={addComment}>Post</button></div>
  </div>);
}
