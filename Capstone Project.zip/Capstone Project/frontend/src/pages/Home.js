import React, {useEffect, useState} from 'react';
import API from '../api';
import VideoCard from '../components/VideoCard';
export default function Home(){
  const [videos,setVideos] = useState([]);
  const [q,setQ] = useState('');
  useEffect(()=>{ fetch(); },[]);
  const fetch = async ()=>{
    const res = await API.get('/videos');
    setVideos(res.data);
  };
  const search = async (e)=>{
    e.preventDefault();
    const res = await API.get('/videos?q='+encodeURIComponent(q));
    setVideos(res.data);
  };
  return (<div className='container'>
    <h2>Home</h2>
    <form onSubmit={search}><input value={q} onChange={e=>setQ(e.target.value)} placeholder='Search videos...'/> <button>Search</button></form>
    <div className='grid' style={{marginTop:12}}>
      {videos.map(v=> <VideoCard key={v._id} v={v} />)}
    </div>
  </div>);
}
