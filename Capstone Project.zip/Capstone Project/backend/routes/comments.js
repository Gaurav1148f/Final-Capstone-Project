const express = require('express');
const router = express.Router();
const Comment = require('../models/Comment');
const auth = require('../middleware/auth');

router.get('/:videoId', async (req,res)=>{
  const comments = await Comment.find({video:req.params.videoId}).populate('user');
  res.json(comments);
});

router.post('/:videoId', auth, async (req,res)=>{
  const {text} = req.body;
  const c = await Comment.create({video:req.params.videoId, user:req.user, text});
  res.json(c);
});

router.put('/:id', auth, async (req,res)=>{
  const c = await Comment.findById(req.params.id);
  if(!c) return res.status(404).json({message:'Not found'});
  if(String(c.user)!==req.user) return res.status(403).json({message:'Forbidden'});
  c.text = req.body.text;
  await c.save();
  res.json(c);
});

router.delete('/:id', auth, async (req,res)=>{
  const c = await Comment.findById(req.params.id);
  if(!c) return res.status(404).json({message:'Not found'});
  if(String(c.user)!==req.user) return res.status(403).json({message:'Forbidden'});
  await c.remove();
  res.json({message:'deleted'});
});

module.exports = router;
