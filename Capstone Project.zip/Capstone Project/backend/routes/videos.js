const express = require('express');
const router = express.Router();
const Video = require('../models/Video');
const auth = require('../middleware/auth');

router.get('/', async (req,res)=>{
  const {q, category} = req.query;
  let filter = {};
  if (q) filter.title = new RegExp(q, 'i');
  if (category) filter.category = category;
  const videos = await Video.find(filter).populate('channel uploader');
  res.json(videos);
});

router.get('/:id', async (req,res)=>{
  const v = await Video.findById(req.params.id).populate('channel uploader');
  if(!v) return res.status(404).json({message:'Not found'});
  res.json(v);
});

router.post('/', auth, async (req,res)=>{
  const {title,description,url,thumbnail,channel,category} = req.body;
  const video = await Video.create({title,description,url,thumbnail,channel,category, uploader:req.user});
  res.json(video);
});

router.put('/:id', auth, async (req,res)=>{
  const v = await Video.findById(req.params.id);
  if(!v) return res.status(404).json({message:'Not found'});
  Object.assign(v, req.body);
  await v.save();
  res.json(v);
});

router.delete('/:id', auth, async (req,res)=>{
  await Video.findByIdAndDelete(req.params.id);
  res.json({message:'deleted'});
});

module.exports = router;
